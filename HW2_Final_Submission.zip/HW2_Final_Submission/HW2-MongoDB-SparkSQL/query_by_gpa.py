
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
collection = client["university"]["students"]

# Get and validate GPA
while True:
    try:
        min_gpa = float(input("Enter minimum GPA (0.0 - 4.0): "))
        if 0.0 <= min_gpa <= 4.0:
            break
        print("GPA must be between 0.0 and 4.0.")
    except ValueError:
        print("Invalid GPA. Please enter a number.")

# Optional course ID
while True:
    course_input = input(
        "Enter Course ID (press Enter to skip): "
    ).strip()

    if course_input == "":
        course_id = None
        break

    try:
        course_id = int(course_input)
        break
    except ValueError:
        print("Invalid Course ID. Please enter an integer.")

# GPA must be strictly greater than the input
query = {"gpa": {"$gt": min_gpa}}

# Add course condition if provided
if course_id is not None:
    query["courseIds"] = course_id

# Find matching students, sorted by GPA descending
students = collection.find(
    query,
    {
        "_id": 1,
        "firstName": 1,
        "lastName": 1,
        "gpa": 1
    }
).sort("gpa", -1)

count = 0

for student in students:
    print(
        f"ID: {student['_id']}, "
        f"Name: {student['firstName']} {student['lastName']}, "
        f"GPA: {student['gpa']}"
    )
    count += 1

print("Number of matches:", count)

client.close()
