
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
collection = client["university"]["students"]

# Get and validate course ID
while True:
    try:
        course_id = int(input("Enter Course ID: "))
        break
    except ValueError:
        print("Invalid input. Please enter an integer.")

# Find students registered in the course
query = {"courseIds": course_id}

students = collection.find(
    query,
    {"_id": 1, "firstName": 1, "lastName": 1, "gpa": 1}
).sort("lastName", 1)

# Display results
count = 0

for student in students:
    print(
        f"ID: {student['_id']}, "
        f"Name: {student['firstName']} {student['lastName']}, "
        f"GPA: {student['gpa']}"
    )
    count += 1

print("Number of matches:", count)

# Explain query execution
explanation = collection.database.command(
    "explain",
    {
        "find": "students",
        "filter": query,
        "projection": {
            "_id": 1,
            "firstName": 1,
            "lastName": 1,
            "gpa": 1
        },
        "sort": {"lastName": 1}
    },
    verbosity="queryPlanner"
)

def has_ixscan(plan):
    if isinstance(plan, dict):
        if plan.get("stage") == "IXSCAN":
            return True
        return any(has_ixscan(value) for value in plan.values())
    if isinstance(plan, list):
        return any(has_ixscan(item) for item in plan)
    return False

winning_plan = explanation["queryPlanner"]["winningPlan"]

print("courseIds index used:", has_ixscan(winning_plan))

client.close()
