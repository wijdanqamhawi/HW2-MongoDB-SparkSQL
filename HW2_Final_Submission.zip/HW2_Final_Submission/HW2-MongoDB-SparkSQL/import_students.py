
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from pymongo import MongoClient, ASCENDING

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
client.admin.command("ping")

db = client["university"]
collection = db["students"]

# Read and parse CSV
csv_path = Path(__file__).parent / "hw2-data.csv"
students = []

with open(csv_path, "r", encoding="utf-8-sig") as file:
    next(file)  # Skip header

    for line in file:
        line = line.strip()
        if not line:
            continue

        # Split while keeping CourseIDs together
        match = re.fullmatch(
            r"(\d+),([^,]+),([^,]+),(\d{4}-\d{2}-\d{2}),"
            r"(\[[\d,\s]+\]),([\d.]+)",
            line
        )

        if not match:
            raise ValueError(f"Invalid CSV row: {line}")

        student_id, first, last, dob, courses, gpa = match.groups()

        student = {
            "_id": int(student_id),
            "firstName": first,
            "lastName": last,
            "dateOfBirth": datetime.strptime(
                dob, "%Y-%m-%d"
            ).replace(tzinfo=timezone.utc),
            "courseIds": json.loads(courses),
            "gpa": float(gpa)
        }

        students.append(student)

# Safe to re-run
collection.drop()

# Insert all documents in one call
result = collection.insert_many(students)

# Create indexes
collection.create_index([("courseIds", ASCENDING)])
collection.create_index([("gpa", ASCENDING)])

# Save JSON Lines for Spark
json_path = Path(__file__).parent / "students.json"

with open(json_path, "w", encoding="utf-8") as file:
    for student in students:
        json_student = student.copy()
        json_student["dateOfBirth"] = student["dateOfBirth"].isoformat()
        file.write(json.dumps(json_student) + "\n")

print("Inserted documents:", len(result.inserted_ids))
print("Indexes:")
for index in collection.list_indexes():
    print(index["name"], index["key"])

client.close()
