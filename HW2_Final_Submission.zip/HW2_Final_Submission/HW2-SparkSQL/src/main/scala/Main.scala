
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Main {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("HW2 Student Analysis")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    // Read students from JSON
    val students = spark.read
      .json("students.json")
      .withColumn(
        "dateOfBirth",
        to_timestamp(col("dateOfBirth"), "yyyy-MM-dd'T'HH:mm:ssXXX")
      )

    // Register students as a temporary SQL view
    students.createOrReplaceTempView("students")

    println("Temporary view 'students' created successfully.")

    println("=== Students Schema ===")
    students.printSchema()

    println("=== First 5 Students ===")
    students.show(5, false)

    println("Total students: " + students.count())

    println("=== Null Dates ===")
    println(
      "Null dates: " +
        students.filter(col("dateOfBirth").isNull).count()
    )

    // ========================================
    // Part 4.1 - Query 1: Students in Course 103
    // ========================================

    println("=== Part 4.1: Students in Course 103 ===")

    val course103 = spark.sql("""
      SELECT _id, firstName, lastName, gpa
      FROM students
      WHERE array_contains(courseIds, 103)
      ORDER BY lastName
    """)

    course103.show(100, false)

    println(
      "Total students in course 103: " + course103.count()
    )

    // ========================================
    // Part 4.1 - Query 2: Students with GPA > 3.5
    // ========================================

    println("=== Part 4.1: Students with GPA > 3.5 ===")

    val highGpaStudents = spark.sql("""
      SELECT _id, firstName, lastName, gpa
      FROM students
      WHERE gpa > 3.5
      ORDER BY gpa DESC
    """)

    highGpaStudents.show(100, false)

    println(
      "Total students with GPA > 3.5: " +
        highGpaStudents.count()
    )

    // ========================================
    // Part 4.2 - Query 1: Explode courseIds
    // ========================================

    println("=== Part 4.2: Enrollments ===")

    val enrollments = spark.sql("""
      SELECT
        _id,
        firstName,
        lastName,
        dateOfBirth,
        gpa,
        explode(courseIds) AS course
      FROM students
    """)

    // Register enrollments as a temporary SQL view
    enrollments.createOrReplaceTempView("enrollments")

    enrollments.show(20, false)

    println(
      "Total enrollments: " + enrollments.count()
    )

    // ========================================
    // Part 4.2 - Query 2: Course Statistics
    // ========================================

    println("=== Part 4.2: Course Statistics ===")

    val courseStats = spark.sql("""
      SELECT
        course,
        COUNT(*) AS studentCount,
        ROUND(AVG(gpa), 2) AS avgGpa,
        MIN(gpa) AS minGpa,
        MAX(gpa) AS maxGpa
      FROM enrollments
      GROUP BY course
      ORDER BY studentCount DESC
    """)

    courseStats.show(false)

    // ========================================
    // Part 4.2 - Query 3: Students by Course Count
    // ========================================

    println("=== Part 4.2: Students by Course Count ===")

    val courseCountDistribution = spark.sql("""
      SELECT
        size(courseIds) AS numberOfCourses,
        COUNT(*) AS studentCount
      FROM students
      WHERE size(courseIds) IN (1, 2, 3)
      GROUP BY size(courseIds)
      ORDER BY numberOfCourses
    """)

    courseCountDistribution.show(false)

    // ========================================
    // Part 4.3 - Query 1: Students by Birth Year
    // ========================================

    println("=== Part 4.3: Students by Birth Year ===")

    val birthYearStats = spark.sql("""
      SELECT
        year(dateOfBirth) AS birthYear,
        COUNT(*) AS studentCount,
        ROUND(AVG(gpa), 2) AS avgGpa
      FROM students
      GROUP BY year(dateOfBirth)
      ORDER BY birthYear
    """)

    birthYearStats.show(false)

    // ========================================
    // Part 4.3 - Query 2: Top 3 Students per Course
    // ========================================

    println("=== Part 4.3: Top 3 Students per Course ===")

    val topStudents = spark.sql("""
      SELECT
        course,
        _id,
        firstName,
        lastName,
        gpa,
        gpaRank
      FROM (
        SELECT
          course,
          _id,
          firstName,
          lastName,
          gpa,
          DENSE_RANK() OVER (
            PARTITION BY course
            ORDER BY gpa DESC
          ) AS gpaRank
        FROM enrollments
      ) ranked
      WHERE gpaRank <= 3
      ORDER BY course, gpaRank, lastName, firstName
    """)

    topStudents.show(100, false)

    // ========================================
    // Part 4.3 - Query 3: Students with Same Full Name
    // ========================================

    println("=== Part 4.3: Students with Same Full Name ===")

    val duplicateNames = spark.sql("""
      SELECT
        s1._id AS student1Id,
        s1.firstName,
        s1.lastName,
        s1.dateOfBirth AS student1BirthDate,
        s2._id AS student2Id,
        s2.dateOfBirth AS student2BirthDate
      FROM students s1
      JOIN students s2
        ON s1.firstName = s2.firstName
       AND s1.lastName = s2.lastName
       AND s1._id < s2._id
      ORDER BY s1.lastName, s1.firstName
    """)

    duplicateNames.show(100, false)

    // ========================================
    // Part 4.3 - Query 4:
    // Students Above Every Enrolled Course Average
    // ========================================

    println("=== Part 4.3: Students Above All Course Averages ===")

    val aboveAllCourseAverages = spark.sql("""
      WITH courseAverages AS (
        SELECT
          course,
          AVG(gpa) AS avgGpa
        FROM enrollments
        GROUP BY course
      )
      SELECT
        s._id,
        s.firstName,
        s.lastName,
        s.gpa
      FROM students s
      WHERE size(s.courseIds) > 0
        AND NOT EXISTS (
          SELECT 1
          FROM enrollments e
          JOIN courseAverages ca
            ON e.course = ca.course
          WHERE e._id = s._id
            AND s.gpa <= ca.avgGpa
        )
      ORDER BY s.gpa DESC, s.lastName
    """)

    aboveAllCourseAverages.show(100, false)

    println(
      "Total students above all course averages: " +
        aboveAllCourseAverages.count()
    )

    // ========================================
    // Part 4.4 - Save Course Statistics to Parquet
    // ========================================

    println("=== Part 4.4: Save Course Statistics ===")

    courseStats.write
      .mode("overwrite")
      .parquet("course_stats.parquet")

    println("Course statistics saved successfully.")

    // ========================================
    // Part 4.4 - Read Saved Course Statistics
    // ========================================

    println("=== Part 4.4: Read Saved Course Statistics ===")

    val savedCourseStats = spark.read
      .parquet("course_stats.parquet")

    savedCourseStats.show(false)

    println(
      "Total saved courses: " + savedCourseStats.count()
    )

    // Stop Spark
    spark.stop()
  }
}
