ThisBuild / scalaVersion := "2.12.18"

name := "HW2-SparkSQL"

version := "0.1.0"

libraryDependencies += "org.apache.spark" %% "spark-sql" % "3.5.7"

fork := true